# E-Commerce html-css

**E-Commerce web site with HTML-CSS and a CSS framework.**
[link](https://pumaclones.herokuapp.com/)


## Aim
Recreate the following website: [link](https://shop.polymer-project.org/), but with a theme of your own. Example: a shoe store, clothing store, electronics store, etc.

## Requirement
* You have require a any browser like Chrome,Firefox,safari etc.
* Require internet connectivity.
